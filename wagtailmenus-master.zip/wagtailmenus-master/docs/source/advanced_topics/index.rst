Advanced topics
===============


.. toctree::
    :maxdepth: 2

    hooks
    custom_menu_classes
