Release notes
=============


.. toctree::
    :maxdepth: 1

    3.0.2
    3.0.1
    3.0
    2.13.1
    2.13
    2.12.1
    2.12
    2.11.1
    2.11
    2.10.1
    2.10.0
    2.9.0
    2.8.0
    2.7.1
    2.7.0
    2.6.0
    2.5.2
    2.5.1
    2.5.0
    2.4.3
    2.4.2
    2.4.1
    2.4.0
    2.3.2
    2.3.1
    2.3.0
    2.2.3
    2.2.2
    2.2.1
    2.2.0
    2.1.4
    2.1.3
    2.1.2
    2.1.1
    2.1.0
    2.0.3
    2.0.2
    2.0.1
    2.0.0

Release notes for versions preceding ``v2.0.0`` can be found on GitHub:
https://github.com/rkhleics/wagtailmenus/releases?after=v2.0.0
