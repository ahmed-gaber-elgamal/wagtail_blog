from wagtailmenus.modeladmin import FlatMenuAdmin, MainMenuAdmin


class CustomFlatMenuModelAdmin(FlatMenuAdmin):
    pass


class CustomMainMenuModelAdmin(MainMenuAdmin):
    pass
