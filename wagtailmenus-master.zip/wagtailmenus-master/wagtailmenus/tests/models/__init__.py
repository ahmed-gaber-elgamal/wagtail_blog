from .pages import *  # noqa
from .menus import *  # noqa
