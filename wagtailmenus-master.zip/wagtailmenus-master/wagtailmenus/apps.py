from django.apps import AppConfig


class WagtailMenusConfig(AppConfig):
    name = 'wagtailmenus'
    verbose_name = 'WagtailMenus'
