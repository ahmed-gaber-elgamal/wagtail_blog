class RemovedInWagtailMenus31Warning(DeprecationWarning):
    pass


removed_in_next_version_warning = RemovedInWagtailMenus31Warning


class RemovedInWagtailMenus32Warning(PendingDeprecationWarning):
    pass


class RemovedInWagtailMenus33Warning(PendingDeprecationWarning):
    pass
