## Authors

* Andy Babic (ababic)
  twitter.com/andyjbabic


## Contributors

* Adrian Tijsseling (adriaant)
* Tim Leguijt (tleguijt)
* Trent Holiday (trumpet2012)
* Tom Dyson (tomdyson)
* Oliver Bestwalter (obestwalter)
* Nguyễn Hồng Quân (hongquan)
* Jérôme Lebleu (jeromelebleu)
* Joshua C. Jackson (inostia)
* Sergey Fedoseev (sir-sigurd)
* Pierre Manceaux (pierremanceaux)
* Michael van de Waeter (mvdwaeter)
* Philipp Bosch (philippbosch) (A Color Bright)
* Oktay Altay (OktayAltay)
* Dan Bentley (danbentley)
* Arkadiusz Michał Ryś (ArkadiuszMichalRys)
* Sekani Tembo (Method Softworks)

## Translators

* François Guérin (frague59)
* Claudio Marinozzi (pyMan)
* Pierre Geier (bloodywing)
* Max Kurama (MaxKurama)
* Matas Dailyda (treavis)
* Alex (einsfr)
* Marcos Amorim (mamorim)
* 汇民 王 (levinewong)
* alyoung
* Clarice Bianchini (claricebbcosta)
* Jérôme Lebleu (jeromelebleu)
* José Luis (SalahAdDin)
* Abdulaziz Alfuhigi (3bdul3ziz)
